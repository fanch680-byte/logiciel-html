import customtkinter as ctk
from tkinter import filedialog, messagebox


# -----------------------------
#   FONCTION DE NETTOYAGE
# -----------------------------
def nettoyer_texte(texte):
    lignes = texte.split("\n")
    resultat = []

    for ligne in lignes:

        # 1) Enlever date + heure + " - "
        pos = ligne.find(" - ")
        if pos != -1:
            ligne = ligne[pos+3:]

        # 2) Si la ligne commence par un numéro → garder seulement le texte
        if ligne.startswith("+") or ligne[:2].isdigit():
            pos2 = ligne.find(":")
            if pos2 != -1:
                ligne = ligne[pos2+1:].lstrip()

        resultat.append(ligne)

    return "\n".join(resultat)


# -----------------------------
#   APPLICATION PRINCIPALE
# -----------------------------
class WhatsAppCleanerApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Nettoyeur WhatsApp - CustomTkinter")
        self.geometry("900x600")

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self.texte_original = ""

        # --- FRAME TOP ---
        self.frame_top = ctk.CTkFrame(self)
        self.frame_top.pack(fill="x", padx=10, pady=10)

        self.btn_import = ctk.CTkButton(self.frame_top, text="Importer fichier", command=self.importer_fichier)
        self.btn_import.pack(side="left", padx=10)

        self.btn_clean = ctk.CTkButton(self.frame_top, text="Nettoyer", command=self.lancer_nettoyage)
        self.btn_clean.pack(side="left", padx=10)

        self.btn_save = ctk.CTkButton(self.frame_top, text="Enregistrer", command=self.sauver_fichier)
        self.btn_save.pack(side="left", padx=10)

        self.btn_theme = ctk.CTkButton(self.frame_top, text="Mode clair / sombre", command=self.toggle_theme)
        self.btn_theme.pack(side="left", padx=10)

        # --- ZONE TEXTE ---
        self.textbox = ctk.CTkTextbox(
            self,
            wrap="word",
            text_color="#E5E5E5",
            font=("Segoe UI", 16)
        )
        self.textbox.pack(fill="both", expand=True, padx=10, pady=10)

    # -----------------------------
    #   IMPORTER FICHIER
    # -----------------------------
    def importer_fichier(self):
        fichier = filedialog.askopenfilename(
            title="Choisir un fichier WhatsApp",
            filetypes=[("Fichiers texte", "*.txt")]
        )

        if fichier:
            with open(fichier, "r", encoding="utf-8", errors="ignore") as f:
                self.texte_original = f.read()

            self.textbox.delete("1.0", "end")
            self.textbox.insert("end", self.texte_original)

    # -----------------------------
    #   NETTOYER TEXTE
    # -----------------------------
    def lancer_nettoyage(self):
        if not self.texte_original:
            messagebox.showwarning("Attention", "Aucun fichier importé.")
            return

        texte_nettoye = nettoyer_texte(self.texte_original)

        self.textbox.delete("1.0", "end")
        self.textbox.insert("end", texte_nettoye)

    # -----------------------------
    #   ENREGISTRER (TXT ou HTML)
    # -----------------------------
    def sauver_fichier(self):
        contenu = self.textbox.get("1.0", "end").strip()

        if not contenu:
            messagebox.showwarning("Attention", "Rien à enregistrer.")
            return

        choix = ctk.CTkInputDialog(
            text="Choisir le format d'enregistrement :\n\n1 = TXT\n2 = HTML",
            title="Format du fichier"
        ).get_input()

        if choix is None:
            return

        # --- TXT ---
        if choix == "1":
            fichier = filedialog.asksaveasfilename(
                title="Enregistrer en TXT",
                defaultextension=".txt",
                filetypes=[("Fichier texte", "*.txt")]
            )

            if fichier:
                with open(fichier, "w", encoding="utf-8") as f:
                    f.write(contenu)

                messagebox.showinfo("Succès", "Fichier TXT enregistré.")
            return

        # --- HTML ---
        if choix == "2":
            fichier = filedialog.asksaveasfilename(
                title="Enregistrer en HTML",
                defaultextension=".html",
                filetypes=[("Fichier HTML", "*.html")]
            )

            if fichier:

                html = """<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>WhatsApp nettoyé</title>
<style>
body {
    background-color: #202020;
    color: #E5E5E5;
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 18px;
    line-height: 1.6;
    white-space: pre-wrap;
}
.radou { color: #4DA3FF; font-weight: 600; }
.autre { color: #FF7AC8; }
</style>
</head>
<body>
"""

                html_contenu = ""

                for ligne in contenu.split("\n"):
                    ligne_strip = ligne.strip()

                    # Supprimer BOM invisible
                    ligne_strip = ligne_strip.replace("\ufeff", "")

                    # Supprimer "- " au début
                    if ligne_strip.startswith("- "):
                        ligne_strip = ligne_strip[2:].lstrip()

                    # Préparation pour la détection
                    test = ligne_strip.lower().replace(" ", "")

                    # Détection Radou
                    if test.startswith("radou:"):
                        html_contenu += f"<span class='radou'>{ligne_strip}</span><br>\n"
                    else:
                        html_contenu += f"<span class='autre'>{ligne_strip}</span><br>\n"

                html += html_contenu + "</body></html>"

                with open(fichier, "w", encoding="utf-8") as f:
                    f.write(html)

                messagebox.showinfo("Succès", "Fichier HTML enregistré.")
            return

        messagebox.showerror("Erreur", "Choix invalide. Tape 1 ou 2.")

    # -----------------------------
    #   MODE CLAIR / SOMBRE
    # -----------------------------
    def toggle_theme(self):
        current = ctk.get_appearance_mode()

        if current == "Dark":
            ctk.set_appearance_mode("Light")
            self.textbox.configure(text_color="#000000")
        else:
            ctk.set_appearance_mode("Dark")
            self.textbox.configure(text_color="#E5E5E5")


# -----------------------------
#   LANCEMENT APP
# -----------------------------
if __name__ == "__main__":
    app = WhatsAppCleanerApp()
    app.mainloop()
